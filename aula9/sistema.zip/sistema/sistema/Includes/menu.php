<ul class="nav justify-content-center">
  <li class="nav-item">
    <a class="nav-link active" href="#">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="cliente.php">Cadastro Cliente</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">Cadastro Fornecedor</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">Cadastro Produto</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="usuario.php">Cadastro Usuário</a>
  </li>
  <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Cadastros
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="#">País</a>
          <a class="dropdown-item" href="#">Estado</a>
          <a class="dropdown-item" href="#">Cidade</a>
          <a class="dropdown-item" href="#">Envio de Email</a>
        </div>
      </li>
  <li class="nav-item">
    <a class="nav-link" href="sair.php">Sair</a>
  </li>
</ul>